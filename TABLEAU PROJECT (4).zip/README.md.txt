https://public.tableau.com/app/profile/nathaniel.solomon/viz/TableauProject_17414065807650/Story?publish=yes

